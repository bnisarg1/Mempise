package com.mphasis.meetingRoom.controller;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.mphasis.meetingRoom.model.BookingModel;

@RestController
public class BookingController {
	
	private String jsonFilePath="C://Workspace//meetingRoom//meetingRoom//src//main//resources//json//";

	@RequestMapping(value="/BookConferenceRoom", method = RequestMethod.POST)
	@ResponseBody()
	public BookingModel updateBookingDetails(@RequestBody BookingModel bm){
		
	//check filename with respect to booking date is already exist or not Exist or not
		DateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd");
		Date date=bm.getDate();
		String dateformat="Date"+dateFormat.format(date)+".json";
		//File
		File file = new File(jsonFilePath+""+dateformat);
		File dir = new File(jsonFilePath+"");
		System.out.println(jsonFilePath+""+dateformat+" is file?"+file.isFile());
		//System.out.println("/meetingRoom/src/main/resources/json?"+dir.isDirectory());
		
	//If false Create a File else update the Existing File
		if(!file.isFile()) //File doesnt Exist Flow
		{	String relativePath = jsonFilePath+""+dateformat;
			try {
				if(file.createNewFile()){
					System.out.println(relativePath+" File Created in Project source directory");
				}
				JSONObject obj = new JSONObject();
				JSONArray MeetingRoom = new JSONArray();
				JSONObject RoomId= new JSONObject();
				
				JSONArray RoomArray= new JSONArray();
				
				//RoomJsonObject
				JSONObject roomObj=new JSONObject();
				//Time Array
				ArrayList<String> list = new ArrayList<String>();
				for(String time:bm.getTime())
				{
					list.add(time);
				}
				roomObj.put("userId",""+bm.getUserId() );
				roomObj.put("Time",list );
				
				RoomArray.add(roomObj);
				
				RoomId.put("Room"+bm.getRoomId(),RoomArray);
				MeetingRoom.add(RoomId);
				obj.put("MeetingRoom", MeetingRoom);
				
				//writing to file
				FileWriter fw=new FileWriter(jsonFilePath+""+dateformat);    
		        fw.write(obj.toJSONString());
				fw.close();
				System.out.println("Successfully Copied JSON Object to File...");
				System.out.println("\nJSON Object: " + obj);
				
				
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			
			
			
			
			
		}
		else //file already exist flow
		{
			
			
			
			
			
		}
		
		
		
		
		
		//If already exist get the json object iterate and Find the whethear that slot is already filled
		//if already filled discared else update it
		
		//return success status else return failure status
		//
		
		
		JSONObject jobj = new JSONObject();
		jobj.put("Name", "Test");
		
		return bm;
		
	}
	
	
	
}
