package com.mphasis.meetingRoom;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class MeetingRoomApplicationTests {

//	@Test
//	public void contextLoads() {
//	}

}
